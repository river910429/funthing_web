function exit()
{
    window.open("/", "_self");
}

function home()
{
    window.open("/home/ta", "_self");
}

function last_page()
{
    window.open("/ta/leaderboard", "_self");
}
