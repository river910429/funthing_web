function entering()
{
    //window.location.href="{{ url_for("test") }}";
    window.open("branch", "_self");
}