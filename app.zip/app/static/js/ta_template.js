function home()
{
    window.open("/home/ta", "_self");
}

function back()
{
    window.open("/ta/template", "_self");
}

function game_catch()
{
    window.open("/template/catch_egg", "_self");
}

function game_map()
{
    window.open("/template/map", "_self");
}

function game_card()
{
    window.open("/template/flipping_card", "_self");
}

function game_fruit()
{
    window.open("/template/fruit_cutter", "_self");
}

