function home()
{
    window.open("/home/stu", "_self");
}

function back()
{
    window.open("/stu/practice", "_self");
}

function poster_catch()
{
    window.open("/poster/catch_egg", "_self");
}

function poster_map()
{
    window.open("/poster/map", "_self");
}

function poster_fruit()
{
    window.open("/poster/fruit_cutter", "_self");
}

function poster_card()
{
    window.open("/poster/flipping_card", "_self");
}


