function home()
{
    window.open("/home/stu", "_self");
}

function back()
{
    window.open("/home/stu", "_self");
}

function game_catch()
{
    window.open("/poster/catch_egg", "_self");
}

function game_map()
{
    window.open("/poster/map", "_self");
}

function game_card()
{
    window.open("/poster/flipping_card", "_self");
}

function game_fruit()
{
    window.open("/poster/fruit_cutter", "_self");
}

