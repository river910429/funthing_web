function teacher_entrance()
{
    // window.open("login/ta", "_self");
    window.location.href = "https://140.116.245.146:7988/login/ta";
}

function student_entrance()
{
    // window.open("login/stu", "_self");
    window.location.href = "https://fenhong.pythonanywhere.com/login/stu";
}