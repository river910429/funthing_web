function manage_entrance()
{
    window.open("/ta/course", "_self");
}

function game_entrance()
{
    window.open("/ta/template", "_self");
}

function leaderboard_entrance()
{
    window.open("/ta/leaderboard", "_self");
}


