

function home()
{
    window.open("/home/stu", "_self");
}

function last_page()
{
    window.open("/stu/leaderboard", "_self");
}
