function practice_entrance()
{
    window.open("/stu/practice", "_self");
}

function game_entrance()
{
    window.open("/stu/game", "_self");
}

function leaderboard_entrance()
{
    window.open("/stu/leaderboard", "_self");
}



function profile()
{
    window.open("/stu/equipment", "_self");
}