function homepage_2_game()
    {
        //window.location.href="{{ url_for("test") }}";
        window.open("game_catch_egg_tutorial", "_self");
    }

function game_catch_egg_start()
{
    //window.location.href="{{ url_for("test") }}";
    window.open("game_catch_egg", "_self");
}    

function show_score_result()
{
    window.open("game_result", "_self")
}